// ejemploclasearea.cpp: Este archivo contiene al funciòn "main"
#include <iostream>
#include "Triangulo.h"

using namespace std;
int main()
{
    Triangulo triangulito;
    cout<<"El area del triangulo es: "<<triangulito.calculararea(5, 6);
    return 0;
}